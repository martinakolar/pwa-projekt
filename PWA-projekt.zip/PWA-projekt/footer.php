<footer class="bg-black text-white ">
    <main class="max-w-screen-lg mx-auto flex flex-col items-center gap-y-2 mt-3 mb-3">
        <p>Autor: Martina Kolar</p>
    <p><a href="mailto:mkolar1@tvz.hr">mkolar1@tvz.hr</a></p>
    <p>&copy; 2024</p>
    </main>
    
</footer>